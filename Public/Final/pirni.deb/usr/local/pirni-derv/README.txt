Add this to your PATH: export PATH=$PWD:$PATH
-------------
What is this?
derv is a collection of scripts for parsing captured network packets; specifically cookies, plain-text passwords, and URLs. derv uses Pirni to capture packets.
