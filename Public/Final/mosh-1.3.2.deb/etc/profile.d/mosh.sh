
# MCApollo Mosh.

# Use this file to set variables for Mosh.
# Could've put this in a post-inst, but this is easier.


export TERMINFO=/usr/share/terminfo/
unset LC_ALL # I set LC_ALL=C for the updatadb command. For some reason it conflicts with mosh.
